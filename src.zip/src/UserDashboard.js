import React, { useState, useEffect } from 'react';

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    // Fetch user data when component loads
    fetch('http://localhost:5000/api/users/update', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })
      .then(res => res.json())
      .then(data => setUser(data))
      .catch(err => console.log('Error fetching user data:', err));
  }, []);

  const handleUpdate = async () => {
    const response = await fetch('http://localhost:5000/api/users/update', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: user.email,
        username: newUsername,
        password: newPassword,
      }),
    });
        
    const data = await response.json();
    if (data.user) {
      setUser(data.user); // Update local state with the updated user info
    } else {
      console.log('Message:', data.message);
    }
  };

  const handleDelete = async () => {
    const response = await fetch('http://localhost:5000/api/users/delete', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: user.email }),
    });

    const data = await response.json();
    console.log(data.message);
    if (data.message === 'User deleted successfully') {
      // Redirect or update the state after successful deletion
    }
  };

  return (
    <div>
      <h1>Welcome to your dashboard</h1>
      {user ? (
        <div>
          <h2>Current Info</h2>
          <p>Username: {user.username}</p>
          <p>Email: {user.email}</p>

          <h3>Update Information</h3>
          <input
            type="text"
            placeholder="New Username"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
          />
          <input
            type="password"
            placeholder="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <button onClick={handleUpdate}>Update</button>
          <h3>Delete User</h3>
          <button onClick={handleDelete}>Delete</button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default UserDashboard;


