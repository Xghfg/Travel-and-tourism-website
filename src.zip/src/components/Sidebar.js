import React from 'react';
import styled from 'styled-components';

const Sidebar = () => (
    <SideMenu>
        <a href="/selectguide">Select Guide</a><br></br>
<br></br>
        <a href="/feedback">Feedback Form</a><br></br>
<br></br>
        <a href="/contact">Contact Us</a><br></br>
<br></br>
        <a href="/aboutus">About Us</a><br></br>
        <br></br>
        <a href="/dashboard">User Dashboard</a><br></br>
        <br></br> 
    </SideMenu>
);

const SideMenu = styled.div`
    padding:20px;
    margin-top:25px;
    margin-bottom:30px;
    background-color:pink;
`;
export default Sidebar;
