import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';


const DestinationPage = () => {
  const { destination } = useParams(); 
  const [destinationData, setDestinationData] = useState(null); 
  const [loading, setLoading] = useState(true); 

  
  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/destination/${destination}`) 
      .then((response) => {
        setDestinationData(response.data); 
        setLoading(false); 
      })
      .catch((error) => {
        console.error("Error fetching destination data:", error);
        setLoading(false); 
      });
  }, [destination]);

  
  if (loading) {
    return <div>Loading...</div>;
  }

  
  if (!destinationData) {
    return <h1>Destination Not Found</h1>;
  }

  return (
    <div>
      <h1>{destinationData.name}</h1>
      <img
        src={destinationData.imageUrl}
        alt={destinationData.name}
        style={{ width: '60%', height: 'auto', margin: '0 auto', display: 'block' }}
      />

      <div>
        <h3>Description</h3>
        <p>{destinationData.description}</p>

        <h3>Country</h3>
        <p>{destinationData.country}</p>

        <h3>Rating</h3>
        <p>{destinationData.rating} / 5</p>

        <h3>Top Attractions</h3>
        {destinationData.attractions && destinationData.attractions.length > 0 ? (
          <ul>
            {destinationData.attractions.map((attraction, index) => (
              <li key={index}>{attraction}</li>
            ))}
          </ul>
        ) : (
          <p>No attractions listed for this destination.</p>
        )}
      </div>
    </div>
  );
};

export default DestinationPage;