import React, { useState, useEffect } from 'react';
import axios from 'axios';
import defaultImage from './about.jpg';  // Default image

const AboutUs = () => {
  const [about, setAbout] = useState({});
  const [visibleSections, setVisibleSections] = useState({
    introduction: false,
    team: false,
    values: false,
    callToAction: false,
  });

  
  useEffect(() => {
    axios.get('http://localhost:5000/api/aboutUs')  
      .then(response => {
        setAbout(response.data);  
      })
      .catch(error => {
        console.error("Error fetching About Us data", error);
      });
  }, []);

  const toggleSection = (section) => {
    setVisibleSections(prevState => ({
      ...prevState,
      [section]: !prevState[section],
    }));
  };

  return (
    <div className="about-us">
      {about && (
        <div className="content-container">
          <div className="about-image">
            <img 
              src={defaultImage} 
              alt="About Us" 
              className="about-image-img"
            />
          </div>

          <div className="about-content">
            <div className="content-sections">
            
              <div className="content-section">
                <h2 onClick={() => toggleSection('introduction')} style={{ cursor: 'pointer' }}>
                  Introduction
                </h2>
                {visibleSections.introduction && <p>{about.introduction}</p>}
              </div>

            
              <div className="content-section">
                <h2 onClick={() => toggleSection('team')} style={{ cursor: 'pointer' }}>
                  Our Team
                </h2>
                {visibleSections.team && (
                  <div className="our-team">
                    {about.ourTeam && about.ourTeam.map((member, index) => (
                      <div className="team-member" key={index}>
                        <img src={member.imageUrl || defaultImage} alt={member.name} />
                        <strong>{member.name}</strong>
                        <p>{member.role}</p>
                        <p>{member.description}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="content-section">
                <h2 onClick={() => toggleSection('values')} style={{ cursor: 'pointer' }}>
                  Our Values
                </h2>
                {visibleSections.values && <p>{about.ourValues}</p>}
              </div>
              <div className="content-section">
                <h2 onClick={() => toggleSection('callToAction')} style={{ cursor: 'pointer' }}>
                  Call-To-Action
                </h2>
                {visibleSections.callToAction && (
                  <div className="call-to-action">
                    <p>{about.callToAction}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default AboutUs;