import React from 'react';
import { Link } from 'react-router-dom'; 
import defaultImage from './dest.jpg'; 
import './App.css';
const Destinations = () => {
  const destinations = ['Bengaluru', 'Mumbai', 'Hyderabad']; 
  return (
    <div className="destination-container">
    
      <h1>Explore Our Destinations</h1>
      <img className="destination-image" src={defaultImage} alt="Destination" />
      <div>
        <h2>Destinations</h2>
        <ul>
          {destinations.map((destination, index) => (
            <li key={index}>
              <Link to={`/destination/${destination}`}>{destination}</Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Destinations;