import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // To get the location from URL
import axios from 'axios';

const SelectGuide = () => {
  const { location } = useParams(); // Get location from the route parameter
  const [guides, setGuides] = useState([]);
  const [selectedGuide, setSelectedGuide] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchGuides = async () => {
      try {
        const { data } = await axios.get(`http://localhost:5000/api/guides/${location}`);
        setGuides(data);
      } catch (error) {
        console.error('Error fetching guides:', error);
      }
    };
    fetchGuides();
  }, [location]);

  const handleSelectGuide = (guide) => {
    setSelectedGuide(guide);
    alert(`You selected ${guide.name}.`);
    navigate('/');
    // Redirect to next step or perform further actions
  };

  return (
    <div className="container mx-auto mt-10 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Select a Guide for {location}</h1>
      {guides.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {guides.map((guide) => (
            <div key={guide._id} className="bg-white shadow rounded p-4 text-center">
              <h2 className="text-xl font-bold mb-2">{guide.name}</h2>
              <p className="text-gray-600 mb-2">Location: {guide.location}</p>
              <p className="text-gray-600 mb-2">Cost per Day: ${guide.guideCost}</p>
              <button
                onClick={() => handleSelectGuide(guide)}
                className="bg-blue-500 text-white px-4 py-2 rounded"
              >
                Select Guide
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-600">No guides available for {location}.</p>
      )}
    </div>
  );
};

export default SelectGuide;