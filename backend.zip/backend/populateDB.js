const mongoose = require('mongoose');
const Feedback = require('./models/Feedback');
const About = require('./models/AboutUs');
const Destination = require('./models/Destination');
const Contact = require('./models/Contact');
const Booking = require('./models/Booking');
const Guide = require('./models/Guide'); // Add Guide model

mongoose.connect('mongodb://localhost:27017/TravelDB')
  .then(() => {
    console.log('MongoDB connected');
    seedDatabase();
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

const sampleAboutData = {
  introduction: 'We are a passionate team of professionals dedicated to providing excellent services.',
  ourTeam: [
    { name: 'Spoorthi', role: 'CEO', description: 'Leads the company.', imageUrl: 'team1.jpg' },
    { name: 'Suman', role: 'CTO', description: 'Heads the technology team.', imageUrl: 'team2.jpg' },
  ],
  ourValues: 'Integrity, Excellence, Innovation',
  callToAction: 'Join us today and be part of something great!',
  imageUrl: 'about.jpg',
};

const sampleDestinationData = [
  {
    name: 'Bengaluru',
    description: 'Bengaluru is known for its parks, nightlife, and tech industry.',
    imageUrl: '/images/bengaluru.jpg',
    attractions: ['Cubbon Park', 'Vidhana Soudha', 'Bangalore Palace'],
    country: 'India',
    rating: 4.5,
  },
  {
    name: 'Mumbai',
    description: 'Mumbai is the financial capital of India, known for its Bollywood and beaches.',
    imageUrl: '/images/mumbai.jpg',
    attractions: ['Gateway of India', 'Marine Drive', 'Juhu Beach'],
    country: 'India',
    rating: 4.2,
  },
  {
    name: 'Hyderabad',
    description: 'Hyderabad is known for its rich culture and cuisine.',
    imageUrl: '/images/hyderabad.jpg',
    attractions: ['Charminar', 'Golconda Fort', 'Hussain Sagar'],
    country: 'India',
    rating: 4.7,
  },
];

const sampleFeedbackData = [
  {
    name: 'Alice',
    email: 'alice@example.com',
    tourName: 'Hyderabad Tour',
    navigation: 'Very Good',
    booking: 'Good',
    payment: 'Satisfactory',
    experience: 'Very Good',
  },
  {
    name: 'Bob',
    email: 'bob@example.com',
    tourName: 'Chennai Tour',
    navigation: 'Good',
    booking: 'Satisfactory',
    payment: 'Poor',
    experience: 'Good',
  },
  {
    name: 'Charlie',
    email: 'charlie@example.com',
    tourName: 'Bengaluru Tour',
    navigation: 'Satisfactory',
    booking: 'Poor',
    payment: 'Good',
    experience: 'Satisfactory',
  },
];

const sampleContactData = [
  {
    _id: new mongoose.Types.ObjectId('6738bf50fecad6c14b581005'),
    name: 'Suman',
    email: 'krsumankumar19@gmail.com',
    message: 'hi',
    createdAt: new Date('2024-11-16T15:50:40.316+00:00'),
    __v: 0,
  },
];

const sampleBookingData = [
  {
    _id: new mongoose.Types.ObjectId('6738ac0bffbb5f19fe938b5e'),
    name:'spoorthi',
    destination: 'Kolar',
    date: new Date('2024-11-08T00:00:00.000+00:00'),
    numPeople: 2,
    __v: 0,
  },
  {
    _id: new mongoose.Types.ObjectId('6738b3e1ffbb5f19fe938b66'),
    name:'vidhya',
    destination: 'Goa',
    date: new Date('2024-11-23T00:00:00.000+00:00'),
    numPeople: 2,
    __v: 0,
  },
  {
    _id: new mongoose.Types.ObjectId('6738ba056bb6591d99d9b0aa'),
    name:'sri',
    destination: 'Mumbai',
    date: new Date('2024-11-21T00:00:00.000+00:00'),
    numPeople: 3,
    __v: 0,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bc3efecad6c14b580fdb'),
    name:'suman',
    destination: 'Ladakh',
    date: new Date('2024-11-08T00:00:00.000+00:00'),
    numPeople: 2,
    __v: 0,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bc57fecad6c14b580fe3'),
    name:'kumar',
    destination: 'Davangere',
    date: new Date('2024-11-29T00:00:00.000+00:00'),
    numPeople: 2,
    __v: 0,
  },
];


const sampleGuideData = [
  {
    _id: new mongoose.Types.ObjectId('6738bac6ab69cd33e8030e2b'),
    name: 'Suman',
    location: 'Ladakh',
    guideCost: 2000,
    available: 'Yes',
    experience: 5,
    languages: ['English', 'Hindi'],
    rating: 4.8,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bb2eab69cd33e8030e2c'),
    name: 'rumar',
    location: 'Kolar',
    guideCost: 1200,
    available: 'Yes',
    experience: 3,
    languages: ['English'],
    rating: 4.5,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bb2eab69cd33e8030e2d'),
    name: 'sumar',
    location: 'Kolar',
    guideCost: 700,
    available: 'Yes',
    experience: 3,
    languages: ['English'],
    rating: 4.5,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bb2eab69cd33e8030e2f'),
    name: 'Kumar',
    location: 'Ladakh',
    guideCost: 1700,
    available: 'Yes',
    experience: 3,
    languages: ['English'],
    rating: 4.5,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bb7aab69cd33e8030e2d'),
    name: 'Darshan',
    location: 'Udaipur',
    guideCost: 2200,
    available: 'No',
    experience: 4,
    languages: ['Hindi', 'Gujarati'],
    rating: 4.6,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bbc7ab69cd33e8030e2e'),
    name: 'Bob',
    location: 'Shimla',
    guideCost: 2700,
    available: 'Yes',
    experience: 6,
    languages: ['English', 'Punjabi'],
    rating: 4.9,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bbc7ab69cd33e8030e2f'),
    name: 'Tom',
    location: 'Shimla',
    guideCost: 3500,
    available: 'Yes',
    experience: 8,
    languages: ['English', 'Hindi'],
    rating: 4.7,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bbc7ab69cd33e8030e2a'),
    name: 'Sri',
    location: 'Goa',
    guideCost: 6500,
    available: 'Yes',
    experience: 7,
    languages: ['English', 'Portuguese'],
    rating: 4.8,
  },
  {
    _id: new mongoose.Types.ObjectId('6738bbc7ab69cd33e8030e2b'),
    name: 'Sanju',
    location: 'Goa',
    guideCost: 7500,
    available: 'Yes',
    experience: 10,
    languages: ['English', 'Hindi', 'Konkani'],
    rating: 4.9,
  },
];

async function seedDatabase() {
  try {
    // Clear existing data
    await About.deleteMany({});
    await Feedback.deleteMany({});
    await Destination.deleteMany({});
    await Contact.deleteMany({});
    await Booking.deleteMany({});
    await Guide.deleteMany({}); // Clear Guides collection

    console.log('Inserting destination data:', sampleDestinationData);
    console.log('Inserting feedback data:', sampleFeedbackData);
    console.log('Inserting About Us data:', sampleAboutData);
    console.log('Inserting contact data:', sampleContactData);
    console.log('Inserting booking data:', sampleBookingData);
    console.log('Inserting guide data:', sampleGuideData);

    // Insert About Us
    const about = new About(sampleAboutData);
    await about.save();
    console.log('About Us data populated successfully');

    // Insert Feedback
    await Feedback.insertMany(sampleFeedbackData);
    console.log('Feedback data populated successfully');

    // Insert Destinations
    await Destination.insertMany(sampleDestinationData);
    console.log('Destination data populated successfully');

    // Insert Contacts
    await Contact.insertMany(sampleContactData);
    console.log('Contact data populated successfully');

    // Insert Bookings
    await Booking.insertMany(sampleBookingData);
    console.log('Booking data populated successfully');

    // Insert Guides
    await Guide.insertMany(sampleGuideData);
    console.log('Guide data populated successfully');

    mongoose.connection.close();
  } catch (err) {
    console.error('Error populating the database:', err);
    mongoose.connection.close();
  }
}