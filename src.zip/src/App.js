
// frontend/src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Home from './components/Home';
import SignUp from './components/SignUp';
import Login from './components/Login';
import UserDashboard from './UserDashboard';
import './styles.css';
import AboutUs from './AboutUs';
import FeedbackForm from './FeedbackForm';
import Destination from './Destination';
import Destinations from './components/Destinations'
import Booking from './pages/Booking';
import BookingConfirmation from './pages/BookingConfirmation';
import SelectGuide from './pages/SelectGuide';
import Contact from './pages/contact';
const App = () => {
    return (
        <Router>
            <Header />
            <div style={{ display: 'flex' }}>
                <Sidebar />
                <div style={{ flex: 1, padding: '20px' }}>
                    
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/home" element={<Home />} />
                        <Route path="/signup" element={<SignUp />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="/dashboard" element={<UserDashboard />} />
                        <Route path="/aboutus" element={<AboutUs />} />
                        <Route path="/feedback" element={<FeedbackForm />} />
                        <Route path="/destination/:destination" element={<Destination />} />
                        <Route path="/destinations" element={<Destinations/>}/>
                        <Route path="/booking" element={<Booking />} />
                        <Route path="/confirmation" element={<BookingConfirmation />} />
                        <Route path="/guides/:location" element={<SelectGuide />} />
                        <Route path="/contact" element={<Contact />} />
                    </Routes>
                </div>
            </div>
        </Router>
    );
};

export default App;
