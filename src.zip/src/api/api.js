import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const getDestinations = () => API.get('/destinations');

// Existing functions...

API.interceptors.request.use((req) => {
  const token = localStorage.getItem('token');
  if (token) req.headers.Authorization =` Bearer ${token}`;
  return req;
});

export const registerUser = (userData) => {
  return API.post('/auth/register', userData);  // POST request to /auth/register endpoint
};
export const loginUser = (userData) => {
  return API.post('/auth/login', userData);  // POST request to /auth/login endpoint
};
export const createBooking = (data) => API.post('/bookings', data);
export const getBookings = () => API.get('/bookings');
