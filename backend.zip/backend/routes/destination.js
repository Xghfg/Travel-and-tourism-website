const express = require('express');
const router = express.Router();
const Destination = require('../models/Destination'); 


router.get('/', async (req, res) => {
  try {
    const destinations = await Destination.find(); 

    if (destinations.length === 0) {
      return res.status(404).json({ message: 'No destinations found' });
    }

  
    res.json(destinations);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


router.get('/:destination', async (req, res) => {
  const { destination } = req.params;
  try {
    const destinationData = await Destination.findOne({ name: destination });

    if (destinationData) {
  
      res.json({
        name: destinationData.name,
        description: destinationData.description,
        imageUrl: destinationData.imageUrl,
        attractions: destinationData.attractions,
        country: destinationData.country,
        rating: destinationData.rating,
      });
    } else {
      res.status(404).json({ message: 'Destination not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;