import React, { useState } from 'react';
import axios from 'axios';

const FeedbackForm = () => {
  const [newFeedback, setNewFeedback] = useState({
    name: '',
    email: '',
    tourName: '',
    navigation: '',
    booking: '',
    payment: '',
    experience: '',
  });


  const handleFeedbackSubmit = (e) => {
    e.preventDefault();

  
    axios.post('http://localhost:5000/api/feedback', newFeedback)
      .then((response) => {
      
        setNewFeedback({
          name: '',
          email: '',
          tourName: '',
          navigation: '',
          booking: '',
          payment: '',
          experience: '',
        });
      
        alert("Feedback submitted successfully!");
      })
      .catch((error) => {
        console.error("Error submitting feedback:", error);
      });
  };

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewFeedback({ ...newFeedback, [name]: value });
  };

  return (
    <div className="feedback-form-container">
      <h1>Feedback</h1>
      <form onSubmit={handleFeedbackSubmit} className="feedback-form">
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={newFeedback.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={newFeedback.email}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="tourName"
          placeholder="Tour Name You Visited"
          value={newFeedback.tourName}
          onChange={handleChange}
          required
        />

        <h3>Ease of Navigation</h3>
        <div className="rating-options">
          {['Very Good', 'Good', 'Satisfactory', 'Poor'].map((option) => (
            <label key={option}>
              <input
                type="radio"
                name="navigation"
                value={option}
                checked={newFeedback.navigation === option}
                onChange={handleChange}
              />
              {option}
            </label>
          ))}
        </div>

        <h3>Booking Process</h3>
        <div className="rating-options">
          {['Very Good', 'Good', 'Satisfactory', 'Poor'].map((option) => (
            <label key={option}>
              <input
                type="radio"
                name="booking"
                value={option}
                checked={newFeedback.booking === option}
                onChange={handleChange}
              />
              {option}
            </label>
          ))}
        </div>
        <h3>Payment Options</h3>
        <div className="rating-options">
          {['Very Good', 'Good', 'Satisfactory', 'Poor'].map((option) => (
            <label key={option}>
              <input
                type="radio"
                name="payment"
                value={option}
                checked={newFeedback.payment === option}
                onChange={handleChange}
              />
              {option}
            </label>
          ))}
        </div>
        <h3>Overall Experience</h3>
        <div className="rating-options">
          {['Very Good', 'Good', 'Satisfactory', 'Poor'].map((option) => (
            <label key={option}>
              <input
                type="radio"
                name="experience"
                value={option}
                checked={newFeedback.experience === option}
                onChange={handleChange}
              />
              {option}
            </label>
          ))}
        </div>
         <h3>REVIEW OF GUIDE</h3>
        <div className="rating-options">
          {['Very Good', 'Good', 'Satisfactory', 'Poor'].map((option) => (
            <label key={option}>
              <input
                type="radio"
                name="navigation"
                value={option}
                checked={newFeedback.navigation === option}
                onChange={handleChange}
              />
              {option}
            </label>
          ))}
        </div>
        <button type="submit">Submit Feedback</button>
      </form>
    </div>
  );
};

export default FeedbackForm;