import React from 'react';
import view from '../assets/view.jpg';
import styled from 'styled-components';
import sri from'../assets/sri.jpg';
const Home = () => (
    <div>
        <Banner src={view} alt="Travel Banner" />
        <Banner src={sri} alt="Travel Banner" />
        <h1>Welcome to ExploreEase</h1>
        <p>Discover amazing destinations and plan your next trip!</p>
    </div>
);
const Banner = styled.img`
    width: 50%;
    height: 300px;
    border-radius: 10px;
    margin-bottom: 50px;
    margin-top:px;
    
`;
export default Home;

