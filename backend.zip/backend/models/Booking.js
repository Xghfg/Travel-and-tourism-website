// backend/models/Booking.js
const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name:String,
  destination: String,
  date: Date,
  numPeople: Number,
});

module.exports = mongoose.model('Booking', bookingSchema);
