import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import logo from '../assets/logo.jpg';
 
const Header = () => (
    <NavBar>
        <Logo src={logo} alt="ExploreEase Logo" />
        <NavLink to="/" >Home</NavLink>
        <NavLink to="/destinations">Destinations</NavLink>
        <NavLink to="/login">Login</NavLink>
        <NavLink to="/booking">Bookings</NavLink>
        <NavLink to="/signup" target="_blank">Sign Up</NavLink>
    </NavBar>
);
const NavBar = styled.div`
    display: flex;
    justify-content: space-around;
    padding-top: 40px;
    font-size:28px;
    background-color: pink;
`;
const Logo = styled.img`
    width: 100px;
    height: auto;
    
`;

export default Header;
