const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/signup', async (req, res) => {
  const { username, email, password } = req.body;
  const newUser = new User({ username, email, password });
  await newUser.save();
  res.status(201).json({ message: 'User registered' });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && user.password === password) {
    res.json(user);
  } else {
    res.status(400).json({ message: 'Invalid credentials' });
  }
});

router.get('/update', async (req, res) => {
  const user = await User.findOne();
  res.json(user);
});
router.put('/update', async (req, res) => {
  const { email, username, password } = req.body;
  await User.findOneAndUpdate({ email }, { username, password });
  res.json({ message: 'User updated' });
});
router.delete('/delete', async (req, res) => {
  const { email } = req.body;
  await User.findOneAndDelete({ email });
  res.json({ message: 'User deleted' });
});
module.exports = router;
