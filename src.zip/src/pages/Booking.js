// frontend/src/pages/Booking.js
import React, { useState, useEffect } from 'react';
import { createBooking, getBookings } from '../api/api';
import { useNavigate } from 'react-router-dom';

const Booking = () => {
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [numPeople, setNumPeople] = useState('');
  const [bookings, setBookings] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const { data } = await getBookings();
        setBookings(data);
      } catch (error) {
        alert('Failed to fetch bookings');
      }
    };
    fetchBookings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createBooking({ destination, date, numPeople });
      alert('Booking successful!');
      setDestination('');
      setDate('');
      setNumPeople('');

      // Redirect to BookingConfirmation with the destination as a state
      navigate('/confirmation', { state: { destlocation: destination } });
    } catch (error) {
      alert('Booking failed');
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-10">
      <form onSubmit={handleSubmit} className="p-6 bg-white shadow rounded mb-10">
        <h2 className="text-2xl font-bold mb-4">Book a Tour</h2>
        <div className='flex flex-col gap-y-10'>
          <input type="text" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="Destination" className="input  border-2 border-black p-2 rounded-lg" required />
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input border-2 border-black  p-2 rounded-lg" required />
          <input type="number" value={numPeople} onChange={(e) => setNumPeople(e.target.value)} placeholder="Number of People" className="input border-2 border-black  p-2 rounded-lg" required />
        </div>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 mt-4 w-full">
          Book Now
        </button>
      </form>

      <div className='border-2 border-black rounded-lg p-4'>
        <h2 className="text-2xl font-bold mb-4">Your Bookings</h2>
        {bookings.length === 0 ? (
          <p>No bookings yet.</p>
        ) : (
          <ul className="space-y-4">
            {bookings.map((booking) => (
              <li key={booking._id} className="p-4 bg-white shadow border-2 border-black rounded-lg">
                {booking.destination} - {booking.date}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Booking;