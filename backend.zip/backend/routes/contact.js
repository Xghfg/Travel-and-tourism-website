// backend/routes/contact.js
const express = require('express');
const router = express.Router();
const Contact = require('../models/Contact'); // Import the Contact model

// POST route to handle contact form submission
router.post('/', async (req, res) => {
  const { name, email, message } = req.body;
  
  try {
    // Create a new Contact document with the form data
    const newContact = new Contact({ name, email, message });
    
    // Save the document to the database
    await newContact.save();
    
    res.status(201).json({ message: 'Message sent successfully!' });
  } catch (error) {
    console.error('Error saving contact message:', error);
    res.status(500).json({ error: 'Failed to send message. Please try again later.' });
  }
});

module.exports = router;

