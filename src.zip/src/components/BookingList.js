// frontend/src/components/BookingList.js
import React, { useEffect, useState } from 'react';
import { getBookings } from '../api/api';

const BookingList = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const fetchBookings = async () => {
      const { data } = await getBookings();
      setBookings(data);
    };
    fetchBookings();
  }, []);

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">Your Bookings</h2>
      <ul className="space-y-4">
        {bookings.map((booking) => (
          <li key={booking._id} className="p-4 bg-white shadow rounded">
            {booking.destination} - {booking.date}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookingList;