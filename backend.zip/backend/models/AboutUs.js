const mongoose = require('mongoose');

const aboutUsSchema = new mongoose.Schema({
  introduction: { type: String, required: true },
  ourTeam: [
    {
      name: { type: String, required: true },
      role: { type: String, required: true },
      description: { type: String, required: true },
      imageUrl: { type: String },
    }
  ],
  ourValues: { type: String, required: true },
  callToAction: { type: String, required: true },
}, { timestamps: true });

module.exports = mongoose.model('AboutUs', aboutUsSchema);