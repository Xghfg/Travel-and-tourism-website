const express = require('express');
const Guide = require('../models/Guide');
const router = express.Router();

// Get Guides by Location
router.get('/:location', async (req, res) => {
  const { location } = req.params;
  try {
    const guides = await Guide.find({ location, available: 'Yes' });
    res.status(200).json(guides);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to fetch guides' });
  }
});

module.exports = router;