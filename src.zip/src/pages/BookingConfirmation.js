import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const BookingConfirmation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { destlocation } = location.state || {};

  const handleSelectGuide = () => {
    navigate(`/guides/${destlocation}`); // Redirect to SelectGuide page with location as a route parameter
  };

  return (
    <div className="container mx-auto mt-10 text-center">
      <h1 className="text-4xl font-bold text-green-500 mb-6">Booking Confirmed!</h1>
      <p className="text-lg mb-6">Your trip to {destlocation} has been booked successfully.</p>
      <button
        onClick={handleSelectGuide}
        className="bg-blue-500 text-white px-6 py-3 rounded"
      >
        Choose a Guide
      </button>
    </div>
  );
};

export default BookingConfirmation;``