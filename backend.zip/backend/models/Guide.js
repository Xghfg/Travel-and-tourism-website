const mongoose = require('mongoose');

const guideSchema = new mongoose.Schema({
  name: { type: String, required: true },
  location: { type: String, required: true },
  guideCost: { type: Number, required: true },
  available: { type: String, enum: ['Yes', 'No'], default: 'Yes' }, // Yes or No
});

const Guide = mongoose.model('Guide', guideSchema);

module.exports = Guide;