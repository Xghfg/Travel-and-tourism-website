const express = require('express');
const router = express.Router();
const AboutUs = require('../models/AboutUs');
router.get('/', async (req, res) => {
  try {
    const aboutUs = await AboutUs.findOne();  
    if (!aboutUs) {
      return res.status(404).json({ message: 'About Us data not found' });
    }
    res.json(aboutUs);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});
router.get('/:section', async (req, res) => {
  const { section } = req.params;
  try {
    const aboutUs = await AboutUs.findOne();
    if (!aboutUs) {
      return res.status(404).json({ message: 'About Us data not found' });
    }
    if (section in aboutUs) {
      return res.json(aboutUs[section]);
    } else {
      return res.status(404).json({ message: 'Section not found' });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});
module.exports = router;
