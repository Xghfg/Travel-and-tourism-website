
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const feedbackRoutes = require('./routes/feedback'); 
const aboutusRoutes = require('./routes/aboutUs');
const destinationRoutes = require('./routes/destination');
const bookingRoutes = require('./routes/bookings');


const guideRoutes = require('./routes/guides');
const contactRoutes =  require('./routes/contact');

// Importing the routes
const userRoutes = require('./routes/users');

const app = express();
const port = 5000;

// Middleware
app.use(cors()); // Enable CORS
app.use(bodyParser.json()); // Parse incoming JSON
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/TravelDB', )
  .then(() => {
    console.log('MongoDB connected');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

// Using the routes
app.use('/api/users', userRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api/destination', destinationRoutes); 
app.use('/api/aboutUs', aboutusRoutes);
app.use('/api/bookings', bookingRoutes);

app.use('/api/contact', contactRoutes);
app.use('/api/guides', guideRoutes);
// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
