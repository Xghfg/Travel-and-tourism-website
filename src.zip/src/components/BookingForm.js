import React, { useState } from 'react';
import { createBooking } from '../api/api';
import { useNavigate } from 'react-router-dom';
const BookingForm = () => {
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [numPeople, setNumPeople] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const booking = { destination, date, numPeople };
    await createBooking(booking); // Create the booking on the backend

    // Redirect to the user dashboard after booking
    navigate('/userdashboard');
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-white shadow rounded">
      <h2 className="text-xl font-bold mb-4">Book a Tour</h2>
      <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      <input type="text" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="Destination" className="input"/>
      <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input"/>
      <input type="number" value={numPeople} onChange={(e) => setNumPeople(e.target.value)} placeholder="Number of People" className="input"/>
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 mt-4">Book Now</button>
    </form>
  );
};
export default BookingForm;
